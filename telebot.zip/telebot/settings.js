const fs = require("fs");
const {
   indonesia
} = require("./language");

// Website Api (jgn di ganti biar gk eror)
global.APIs = {
   alfa: 'https://api.zeeoneofc.my.id', //apabila link api eror, segera laporkan ke owner
}

//buy apikey premium 0887435047326
// Free apikey (silahkan login terus ganti Your Key dgn apikey lu)
global.APIKeys = {
   'https://api.zeeoneofc.my.id': 'hikveLZ3dhc5fJk', // 👉 login https://api.zeeoneofc.my.id to get apikey
}

//language 
global.language = indonesia //change indonesia to english if you don't understand the language used by the bot

global.BOT_TOKEN = "5921341515:AAHqqzOJAB_XetW1QkuuLmm-eqDUfOn7Pos"
global.BOT_NAME = "LieeBotz-Mdོ" 
global.OWNER_NAME = "Liezz" 
global.OWNER_NUMBER = "6285758409674" 
global.OWNER = ["https://t.me/LiezzSt"] 
global.THUMBNAIL = "./image/lol.jpg" 
global.DONASI = "./image/donasi.jpg" 
global.lang = language 
